"use client";

import Image from "next/image";
import Link from "next/link";

const navItems = [
  { title: "Home", href: "/" },
  { title: "Solutions", href: "#solutions" },
  { title: "Industries", href: "#industries" },
  { title: "Knowledge Center", href: "#knowledge" },
  { title: "About", href: "#about" },
  { title: "Contact", href: "#contact" },
];

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-[88px] bg-gradient-to-r from-[#0a2345] via-[#123d73] to-[#0a2345] shadow-md">
      <div className="max-w-7xl h-full mx-auto px-8 flex items-center justify-between">

        {/* Logo */}
        <Link href="/" className="flex items-center">
          <Image
            src="/logo.png"
            alt="TPS"
            width={220}
            height={60}
            priority
            className="h-[60px] w-auto"
          />
        </Link>

        {/* Navigation */}
        <nav className="hidden lg:flex items-center gap-10">
          {navItems.map((item) => (
            <Link
              key={item.title}
              href={item.href}
              className="relative text-white font-semibold transition duration-300 hover:text-green-400 after:absolute after:left-0 after:-bottom-2 after:h-[2px] after:w-0 after:bg-green-400 after:transition-all after:duration-300 hover:after:w-full"
            >
              {item.title}
            </Link>
          ))}
        </nav>

        {/* Button */}
        <Link
          href="#contact"
          className="hidden lg:inline-flex items-center rounded-full bg-green-600 px-7 py-3 font-semibold text-white transition hover:bg-green-500"
        >
          Get a Quote
        </Link>

      </div>
    </header>
  );
}